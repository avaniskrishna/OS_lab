#Online Bash Shell.
#Code, Compile, Run and Debug Bash script online.
#Write your code in this editor and press "Run" button to execute it.
echo "Hello World";

#!/bin/bash
echo -e "Enter Number : \c"
read n
for((i=2; i<=$n/2; i++))
do
  ans=$(( n%i ))
  if [ $ans -eq 0 ]             #not equal= -ne, equal = -eq
  then
    echo "$n is not a prime number."
    exit 0
  fi
done
echo "$n is a prime number."

